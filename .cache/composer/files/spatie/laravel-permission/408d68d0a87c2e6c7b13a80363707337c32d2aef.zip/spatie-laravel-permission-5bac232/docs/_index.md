---
title: v3
slogan: Associate users with roles and permissions
githubUrl: https://github.com/spatie/laravel-permission
branch: master
---
