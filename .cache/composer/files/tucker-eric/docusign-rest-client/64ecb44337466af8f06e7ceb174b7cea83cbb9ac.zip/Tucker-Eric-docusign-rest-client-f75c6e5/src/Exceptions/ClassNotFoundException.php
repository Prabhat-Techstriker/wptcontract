<?php

namespace DocuSign\Rest\Exceptions;

class ClassNotFoundException extends \Exception
{

}