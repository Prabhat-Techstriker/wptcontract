<?php

define('USERNAME', '');
define('PASSWORD', '');
define('INTEGRATOR_KEY', '');
define('HOST', 'https://demo.docusign.net/restapi');
define('TEST_EMAIL', '');
define('TEST_RECIPIENT', '');
define('DOCUMENT_FILE_NAME', __DIR__.'/Docs/SignTest1.pdf');
define('DOCUMENT_NAME', __DIR__.'/Docs/SignTest1.docx');